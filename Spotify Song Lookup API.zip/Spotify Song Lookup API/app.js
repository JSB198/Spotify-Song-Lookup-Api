// Use of package prompts to handle user input from the command line
const prompts = require('prompts');
const { doSpotify } = require('./lib.js');

// Function displays the initial startup menu that is displayed first to the user
function startUpMenu(){
    // Async funcion waits for user input before continuing, prompts package has a built in validate function that checks user input
    (async () => {
        const response = await prompts({
            type: 'number',
            name: 'value',
            message: '====== Menu ====== \n(1) Twitter Lookup (Not Available - Thanks Elon)\n(2) Spotify Lookup\nPlease pick an option:',
            validate: value => value !== 2?`Please pick from available options!` : true
        });
    if(response.value == 1)
        {
            twitterMenu()
        }
    else if(response.value == 2)
        {
            spotifyMenu();
        }
    })();
}
  // Function takes user input for a twitter username and formats the response with the @ handle
  // Not longer usable thanks to changes to Twitter API
function twitterMenu(){
(async function(){
    const questions = [
        {
            type: 'text',
            name: 'twitter',
            message: `What's your twitter handle?`,
            format: v => `@${v}`
        },
        {
            type: 'number',
            name: 'numTweets',
            message: 'How many tweets do you want?'
        }
    ];
    const answers = await prompts(questions);
    console.log("Twitter API no longer allows tweet lookups on the free plan!");
})()    
}
// Function that displays the menu concern for the spotify lookup functionality
function spotifyMenu(){
    console.log("");
    (async () => {
        const response = await prompts({
            type: 'text',
            name: 'track',
            message: '============ Spotify Menu ============\nPlease enter name of track to lookup:'
        });
        // Use of promises to ensure that the spotify lookup runs before the confirmation menu is run
        doSpotify(response.track).then((value) =>{ if (value === "Success!") return confirmMenu()}).catch((error) => console.log("Error!: "+ error));
        })();

}
// Confirmation menu to ask user if they want to continue looking up songs
function confirmMenu(){   
    (async () => {
        const confirm = await prompts({
            type: 'confirm',
            name: 'value',
            message: 'Look up another song?',
            initial: true
          });
          if (confirm.value == true)
            {
                console.clear();
                spotifyMenu();
            }
         else(
            console.log("======== Exiting ======== ")
         )
    })();
}
startUpMenu();


