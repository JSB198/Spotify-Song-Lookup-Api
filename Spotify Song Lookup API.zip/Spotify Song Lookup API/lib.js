
// Function handles the request to the Spotify API including mandatory retrieving and granting of access tokens
function doSpotify(name){
  return new Promise((resolve, reject) => {
    // Importing the spotify-web-api-node module
    var SpotifyWebApi = require('spotify-web-api-node');
  
    // Setting credentials of spotify dev account
    var clientId = '076af67adb6f4f098b84c54604a8a7bf',
    clientSecret = 'a5b8bb7224da495696bf7fe08538ccce';
    
    // Create the api object with the credentials
    var spotifyApi = new SpotifyWebApi({
      clientId: clientId,
      clientSecret: clientSecret
    });
    
    // Retrieve an access token. (Using Implicit authentication method (1 of 3 possible authentication methods))
    spotifyApi.clientCredentialsGrant().then(
      function(data) {
        // Logging retrieved access token and when it expires
        console.log('The access token expires in ' + data.body['expires_in']);
        console.log('The access token is ' + data.body['access_token']);
    
        // Save the access token so that it can be used with our subsequent call 
        spotifyApi.setAccessToken(data.body['access_token']);
      },
      function(err) {
        console.log('Something went wrong when retrieving an access token', err);
      }
    ).then(() => {
        let search = name;
  
        // Searches spotify using .searchTracks function from the module specifying we are looking for a track name
        spotifyApi.searchTracks(`track: ${search}`)
        .then(function(data) {
        let count = 0;
  
  
        // Iterate over the data JSON object that is returned and print only the information we are looking for
        // Spotify limits the amount of returns to 20
        for(var item in data.body.tracks.items)
        {
            // If name of track is an exact match for what the user inputted, it is printed as an exact match
            if(data.body.tracks.items[count].name.toLowerCase() === search.toLowerCase()){
                let artistCount = 0;
                console.log("")
                console.log("Exact Match");
                console.log(`(${count+1}) ---------------------------`);
                console.log('Song Name: ', data.body.tracks.items[count].name);
                // For in loop that prints out all artists of the song and labels them Artist (1) then Artist 2) etc.
                for(var artist in data.body.tracks.items[count].artists)
                  {  
                    artistCount++;
                    console.log(`Artist (${artistCount}) Name: `, data.body.tracks.items[count].artists[artist].name);
                  }
                console.log('Album Name: ', data.body.tracks.items[count].album.name);
                console.log('Preview Url: ', data.body.tracks.items[count].preview_url);
                console.log("--------------------------------");
            }
            else{
              // If the name of the track only includes part of the string the user inputted, it is printed as a partial match
                let artistCount = 0;
                console.log("")
                console.log("Partial Match");
                console.log(`(${count+1}) ---------------------------`);
                console.log('Song Name: ', data.body.tracks.items[count].name);
                for(var artist in data.body.tracks.items[count].artists)
                  {  
                    artistCount++;
                    console.log(`Artist (${artistCount}) Name: `, data.body.tracks.items[count].artists[artist].name);
                  }
                console.log('Album Name: ', data.body.tracks.items[count].album.name);
                console.log('Preview Url: ', data.body.tracks.items[count].preview_url);
                console.log("--------------------------------");
            }
            count ++;
       
        }
        resolve("Success!")
        }, function(err) {
          console.error(err);
          reject(err);
        });
    })
  })
}

// Export the module for SOC and abstraction
module.exports.doSpotify = doSpotify;


